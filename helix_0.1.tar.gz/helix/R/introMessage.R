#'
#' @author Harald Fiedler
#' @description Druckt eine Nachricht aus. 
#' @details Druckt eine Begrüßungs-Message aus.
#' @title introMessage
introMessage <- function(){
  message("Paket helix Version 0.1")
}
