Foo <- function(x){
  return(x**2)
}